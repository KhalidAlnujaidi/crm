from flask import Flask, request, jsonify
from flask_cors import CORS
from models import init_db, add_contact, get_all_contacts

app = Flask(__name__)
CORS(app)

@app.route('/health')
def health():
    return {'status': 'ok'}

@app.route('/init_db')
def initialize_db():
    init_db()
    return {'status': 'db initialized'}

@app.route('/contacts', methods=['GET'])
def list_contacts():
    contacts = get_all_contacts()
    return jsonify(contacts)

@app.route('/contacts', methods=['POST'])
def create_contact():
    data = request.get_json()
    team_member = data.get('team_member')
    company_name = data.get('company_name')
    contact_details = data.get('contact_details', '')
    if not team_member or not company_name:
        return {'error': 'Missing required fields'}, 400
    add_contact(team_member, company_name, contact_details)
    return {'status': 'contact added'}

if __name__ == '__main__':
    app.run(debug=True)
